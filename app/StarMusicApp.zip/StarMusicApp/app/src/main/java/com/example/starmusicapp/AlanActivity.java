package com.example.starmusicapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.example.starmusicapp.Adapter.SliderAdapter;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.slider.Slider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.ktx.Firebase;

import java.util.ArrayList;
import java.util.List;

public class   AlanActivity extends AppCompatActivity {
    BottomNavigationView nav_bar;

    ViewPager2 viewPager2;
    DatabaseReference mref;
    TextView SongName, SongAuth;

    MediaPlayer mediaPlayer;
    boolean play = true;
    ImageView Play,Pause,Prev,Next;
    Integer currentSongIndex = 0;
    SeekBar seekBar;
    TextView Pass,Due;
    Handler handler;
    String out,out2;
    Integer totalTime;

    ArrayList<String> imageurls= new ArrayList<>();
    ArrayList<String> songnames= new ArrayList<>();
    ArrayList<String> songauths= new ArrayList<>();
    ArrayList<String> songurls= new ArrayList<>();

    List<SliderItem> sliderItems= new ArrayList<>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alan);
        nav_bar = findViewById(R.id.nav_bar);
        nav_bar.setSelectedItemId(R.id.home);
        nav_bar.setOnItemSelectedListener(getListener());
        viewPager2 = findViewById(R.id.alanviewpageimageslider);
        mref = FirebaseDatabase.getInstance().getReference();
        SongName = (TextView)findViewById(R.id.songname);
        SongAuth = (TextView)findViewById(R.id.songauth);
        seekBar = (SeekBar)findViewById(R.id.seek_bar);
        Pass = (TextView)findViewById(R.id.tv_pass);
        Due = (TextView)findViewById(R.id.tv_due);
        handler = new Handler();
        Play = (ImageView)findViewById(R.id.play);
        Pause = (ImageView)findViewById(R.id.pause);
        Prev = (ImageView)findViewById(R.id.prev);
        Next = (ImageView)findViewById(R.id.next);
        mref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds:snapshot.getChildren())
                {
                    imageurls.add(ds.child("imageurl").getValue(String.class));
                    songnames.add(ds.child("songname").getValue(String.class));
                    songauths.add(ds.child("songauth").getValue(String.class));
                    songurls.add(ds.child("songurl").getValue(String.class));
                }
                for (int i = 0;i<imageurls.size();i++)
                {
                    sliderItems.add(new SliderItem(imageurls.get(i)));
                }
                viewPager2.setAdapter(new SliderAdapter(sliderItems));
                viewPager2.setClipToPadding(false);
                viewPager2.setClipChildren(false);
                viewPager2.setOffscreenPageLimit(3);
                viewPager2.getChildAt(0).setOverScrollMode(RecyclerView.OVER_SCROLL_NEVER);
                CompositePageTransformer compositePageTransformer = new CompositePageTransformer();
                compositePageTransformer.addTransformer(new MarginPageTransformer(40));
                compositePageTransformer.addTransformer(new ViewPager2.PageTransformer() {
                    @Override
                    public void transformPage(@NonNull View page, float position) {
                        page.setScaleY(1);
                    }
                });
                viewPager2.setPageTransformer(compositePageTransformer);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                init(viewPager2.getCurrentItem());
                currentSongIndex = viewPager2.getCurrentItem();
            }
        });
        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.reset();
                currentSongIndex = currentSongIndex +1;
                viewPager2.setCurrentItem(currentSongIndex);
                init(currentSongIndex);

            }
        });
        Prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.reset();
                currentSongIndex = currentSongIndex -1;
                viewPager2.setCurrentItem(currentSongIndex);
                init(currentSongIndex);
            }
        });
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(b)
                {
                    mediaPlayer.seekTo(i*1000);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
    private void init(int currentItem) {
        try{
            if(mediaPlayer.isPlaying()){
                mediaPlayer.reset();
            }
        }catch (Exception e){}
        Pause.setVisibility(View.VISIBLE);
        Play.setVisibility(View.INVISIBLE);
        SongName.setText(songnames.get(currentItem));
        SongAuth.setText(songauths.get(currentItem));
        try{
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(songurls.get(currentItem));
            mediaPlayer.prepareAsync();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mediaPlayer) {
                    mediaPlayer.start();
                    initializeSeekBar();
                }
            });
        }
        catch (Exception e){e.printStackTrace();}
    }

    private void initializeSeekBar() {
        seekBar.setMax(mediaPlayer.getDuration()/1000);
        int mCurrentPosition =mediaPlayer.getCurrentPosition()/1000;
        seekBar.setProgress(mCurrentPosition);
        AlanActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if(mediaPlayer != null)
                {
                    int mCurrentPosition = mediaPlayer.getCurrentPosition()/1000;
                    seekBar.setProgress(mCurrentPosition);
                    out =String.format("%02d:%02d",seekBar.getProgress()/60,seekBar.getProgress()%60);
                    Pass.setText(out);
                }
                handler.postDelayed(this,1000);
            }
        });
        totalTime = mediaPlayer.getDuration()/1000;
        out2 =String.format("%02d:%02d",totalTime/60,totalTime%60);
        Due.setText(out2);
    }

    public void playpausebutton(View view){
        if(play)
        {
            play = false;
            Pause.setVisibility(View.INVISIBLE);
            Play.setVisibility(View.VISIBLE);
            mediaPlayer.pause();
        }
        else
        {
            play = true;
            Pause.setVisibility(View.VISIBLE);
            Play.setVisibility(View.INVISIBLE);
            mediaPlayer.start();
        }
    }
    private NavigationBarView.OnItemSelectedListener getListener() {
        return new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.home:
                        return true;
                    case R.id.search:
                        startActivity(new Intent(getApplicationContext(),SearchActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.list:
                        startActivity(new Intent(getApplicationContext(),PlayListActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        };
    }
}