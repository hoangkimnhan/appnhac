package com.example.starmusicapp;

public class SliderItem {
    public String image;
    public SliderItem(String image){
        this.image = image;
    }
    public String getImage() {
        return image;
    }
}
