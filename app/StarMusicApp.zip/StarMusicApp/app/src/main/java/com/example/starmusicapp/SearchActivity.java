package com.example.starmusicapp;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class SearchActivity extends AppCompatActivity {

    BottomNavigationView nav_bar;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        nav_bar = findViewById(R.id.nav_bar);
        nav_bar.setSelectedItemId(R.id.search);
        nav_bar.setOnItemSelectedListener(getListener());
    }

    private NavigationBarView.OnItemSelectedListener getListener() {
        return new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()) {
                    case R.id.home:
                         startActivity(new Intent(getApplicationContext(),AlanActivity.class));
                         overridePendingTransition(0,0);
                         return true;
                    case R.id.search:
                        return true;
                    case R.id.list:
                        startActivity(new Intent(getApplicationContext(),PlayListActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return true;
            }
        };
    }
}